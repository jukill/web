const fs = require('fs');
const express = require('express');
const app = express();
const request = require('request');
const bp = require('body-parser');
const apiKey = '53653e7ec658c3afcf65ed7b56228fbb';

app.use(express.static('public'));
app.use(bp.urlencoded({extended: true}));
app.set('view engine', 'ejs');

app.get('/',function(req, res){
    res.render('index', {weather: null, error: null});
});
app.post('/',function(req, res){
    let city = req.body.city;
    let url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    request(url, function(err, response, body) {
        if(err) {
            res.render('index', {weather: null, error: 'please try again'});
        }
        else{
            let weather = JSON.parse(body);
            if(weather.main == undefined) {
                res.render('index', {weather: null, error: 'please try again'});
            }
            else{
                let weatherText = `suhu : ${weather.main.temp} derajat`;
                let terbenam = `sunset : ${weather.sys.sunset}`;
                let nama = `${weather.name}`;
                let suhu = `${weather.main.temp}`;
                let angin = `${weather.wind.deg}`;
                let kecepatan = `${weather.wind.speed}`;
                let lembab = `${weather.main.humidity}`;
                res.render('index', {weather: weatherText, suhu:suhu, speed:kecepatan, arah: angin, sunset:terbenam, name:nama, cloud:lembab, error: null});
                console.log(weather)
            }
        }
    })
});

app.listen(8888, function(){
    console.log('server jalan');
});